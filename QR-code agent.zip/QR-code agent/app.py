import streamlit as st
import qrcode
from PIL import Image
from pyzbar.pyzbar import decode
import numpy as np
import io

# -----------------------------------
# App Title
# -----------------------------------
st.set_page_config(page_title="QR Code Generator & Scanner", page_icon="📱")

st.title("📱 QR Code Generator & Scanner")
st.write("Generate and Scan QR Codes Easily")

# -----------------------------------
# Sidebar
# -----------------------------------
st.sidebar.title("Menu")

option = st.sidebar.radio(
    "Choose an Option",
    ["Generate QR Code", "Scan QR Code"]
)

# ===================================
# GENERATE QR CODE
# ===================================
if option == "Generate QR Code":

    st.header("📤 Generate QR Code")

    qr_text = st.text_input("Enter Text or URL")

    if st.button("Generate QR Code"):

        if qr_text.strip() == "":
            st.warning("Please enter some text.")

        else:

            # Create QR
            qr = qrcode.make(qr_text)

            # Save in Memory
            buffer = io.BytesIO()
            qr.save(buffer, format="PNG")
            buffer.seek(0)

            # Display
            st.image(buffer, caption="Generated QR Code")

            # Download
            st.download_button(
                label="📥 Download QR Code",
                data=buffer.getvalue(),
                file_name="qrcode.png",
                mime="image/png"
            )

            st.success("QR Code Generated Successfully!")

# ===================================
# SCAN QR CODE
# ===================================
elif option == "Scan QR Code":

    st.header("🔍 Scan QR Code")

    uploaded_file = st.file_uploader(
        "Upload QR Code Image",
        type=["png", "jpg", "jpeg"],
        key="scanner"
    )

    if uploaded_file is not None:

        image = Image.open(uploaded_file).convert("RGB")

        st.image(image, caption="Uploaded QR Code")

        img = np.array(image)

        decoded = decode(img)

        if decoded:

            st.success("✅ QR Code Detected!")

            for obj in decoded:

                qr_data = obj.data.decode("utf-8")

                st.subheader("Decoded Text")

                st.code(qr_data)

                if qr_data.startswith("http://") or qr_data.startswith("https://"):

                    st.link_button("🌐 Open Link", qr_data)

        else:

            st.error("❌ No QR Code Found.")